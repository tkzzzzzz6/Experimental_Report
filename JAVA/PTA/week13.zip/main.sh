#! /bin/bash

javac src/APlusB.java
cd src
java APlusB
cat ../c.txt
