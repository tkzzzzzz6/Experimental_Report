#!/bin/sh
cd "$(dirname "$0")"   # 保证脚本在week13目录下运行
javac src/APlusB.java
java -cp src APlusB
cat c.txt
